"""
╔══════════════════════════════════════════════════════════════════╗
║      AI-BASED SMART EXPENSE TRACKER WITH BUDGET ALERT SYSTEM    ║
║           B.Tech AI / Data Science Project — Terminal Edition   ║
╚══════════════════════════════════════════════════════════════════╝

Run:  python expense_tracker.py

Features:
  • Add an expense (AI auto-categorizes it by description keywords)
  • Set / update monthly budget per category
  • View all expenses in a formatted table
  • Filter expenses by category, month, or payment mode
  • Budget Alert System  — warns at 80 % usage, alerts at 100 %
  • Monthly summary with bar-chart spending overview
  • Delete an expense
  • All data persisted in SQLite (expenses.db)
"""

import sqlite3
import os
import sys
from datetime import datetime, date

# ── Try to import 'rich' for coloured TUI; fall back to plain text ──
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich import box
    from rich.rule import Rule
    from rich.progress import BarColumn, Progress, TextColumn
    RICH = True
except ImportError:
    RICH = False

# ─────────────────────────────────────────────────────────────────
# 1. DATABASE SETUP
# ─────────────────────────────────────────────────────────────────
DATABASE = "expenses.db"


def get_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """
    Creates two tables:
      expenses — every spending record
      budgets  — monthly budget limit per category
    """
    conn = get_connection()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            description  TEXT    NOT NULL,
            amount       REAL    NOT NULL,
            category     TEXT    NOT NULL,
            payment_mode TEXT    NOT NULL,
            note         TEXT    DEFAULT '',
            expense_date TEXT    NOT NULL,
            created_at   TEXT    NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS budgets (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            category   TEXT    NOT NULL UNIQUE,
            monthly_limit REAL NOT NULL,
            updated_at TEXT    NOT NULL
        )
    """)

    conn.commit()
    conn.close()


# ─────────────────────────────────────────────────────────────────
# 2. AI CLASSIFICATION ENGINE
# ─────────────────────────────────────────────────────────────────

CATEGORY_KEYWORDS = {
    "Food & Dining": [
        "food", "lunch", "dinner", "breakfast", "restaurant", "cafe",
        "coffee", "tea", "snack", "pizza", "burger", "biryani", "zomato",
        "swiggy", "hotel", "meal", "eat", "grocery", "vegetables", "fruits",
        "milk", "bread", "rice", "dal", "chicken", "mutton", "juice"
    ],
    "Transport": [
        "petrol", "diesel", "fuel", "bus", "auto", "cab", "uber", "ola",
        "metro", "train", "flight", "ticket", "parking", "toll", "bike",
        "car", "taxi", "travel", "commute", "vehicle", "maintenance"
    ],
    "Shopping": [
        "shop", "clothes", "shirt", "jeans", "shoes", "dress", "amazon",
        "flipkart", "myntra", "purchase", "buy", "order", "online",
        "store", "mall", "market", "electronics", "mobile", "laptop"
    ],
    "Utilities": [
        "electricity", "water", "gas", "wifi", "internet", "broadband",
        "phone", "recharge", "bill", "subscription", "netflix", "hotstar",
        "spotify", "ott", "dth", "cable", "maintenance", "rent"
    ],
    "Health": [
        "medicine", "doctor", "hospital", "clinic", "pharmacy", "medical",
        "health", "gym", "fitness", "lab", "test", "scan", "dentist",
        "tablet", "injection", "therapy", "insurance"
    ],
    "Education": [
        "book", "course", "fees", "college", "school", "tuition", "udemy",
        "coursera", "exam", "stationery", "notebook", "pen", "study",
        "coaching", "tutorial", "certification", "library"
    ],
    "Entertainment": [
        "movie", "cinema", "game", "concert", "event", "outing", "party",
        "trip", "tour", "hotel stay", "pub", "bar", "club", "fun",
        "recreation", "sport", "cricket", "football", "hobby"
    ],
    "Savings & Investment": [
        "savings", "investment", "mutual fund", "sip", "stock", "fd",
        "rd", "gold", "insurance premium", "ppf", "nps", "deposit"
    ],
}

CATEGORY_ICONS = {
    "Food & Dining":        "🍽️",
    "Transport":            "🚗",
    "Shopping":             "🛒",
    "Utilities":            "💡",
    "Health":               "🏥",
    "Education":            "📚",
    "Entertainment":        "🎬",
    "Savings & Investment": "💰",
    "Other":                "📋",
}

PAYMENT_MODES = ["UPI", "Cash", "Credit Card", "Debit Card", "Net Banking", "Other"]


def ai_classify(description: str) -> str:
    """
    Scores the description against every category's keyword list.
    Returns the highest-scoring category, or 'Other' if no match.
    """
    text = description.lower()
    scores = {cat: 0 for cat in CATEGORY_KEYWORDS}
    for cat, keywords in CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if kw in text:
                scores[cat] += 1
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "Other"


# ─────────────────────────────────────────────────────────────────
# 3. BUDGET ALERT ENGINE  ← Core feature of the project
# ─────────────────────────────────────────────────────────────────

ALERT_THRESHOLD_WARN  = 0.80   # 80 % → warning
ALERT_THRESHOLD_LIMIT = 1.00   # 100 % → over budget


def get_monthly_spent(category: str, year: int, month: int) -> float:
    """Returns total spending in a category for the given year-month."""
    conn = get_connection()
    month_str = f"{year}-{month:02d}"
    row = conn.execute(
        """SELECT COALESCE(SUM(amount), 0) as total
           FROM expenses
           WHERE category = ? AND expense_date LIKE ?""",
        (category, f"{month_str}%")
    ).fetchone()
    conn.close()
    return float(row["total"])


def get_budget_limit(category: str) -> float:
    """Returns the set monthly budget for a category, or 0 if not set."""
    conn = get_connection()
    row = conn.execute(
        "SELECT monthly_limit FROM budgets WHERE category = ?", (category,)
    ).fetchone()
    conn.close()
    return float(row["monthly_limit"]) if row else 0.0


def check_budget_alert(category: str, year: int, month: int) -> dict:
    """
    Core alert function.

    Returns a dict:
      {
        'limit':    float,   # budget limit (0 = not set)
        'spent':    float,   # total spent this month
        'percent':  float,   # spent / limit  (0 if no limit)
        'status':   str,     # 'ok' | 'warning' | 'exceeded' | 'no_budget'
        'message':  str,     # human-readable alert message
      }
    """
    limit = get_budget_limit(category)
    spent = get_monthly_spent(category, year, month)

    if limit == 0:
        return {
            "limit":   0,
            "spent":   spent,
            "percent": 0,
            "status":  "no_budget",
            "message": f"No budget set for {category}. Spent ₹{spent:,.2f} this month.",
        }

    percent = spent / limit

    if percent >= ALERT_THRESHOLD_LIMIT:
        status  = "exceeded"
        message = (
            f"🚨 BUDGET EXCEEDED!  {category}: "
            f"Spent ₹{spent:,.2f} of ₹{limit:,.2f} ({percent*100:.1f}%)"
        )
    elif percent >= ALERT_THRESHOLD_WARN:
        status  = "warning"
        message = (
            f"⚠️  Budget Warning!  {category}: "
            f"Spent ₹{spent:,.2f} of ₹{limit:,.2f} ({percent*100:.1f}%) — nearly full"
        )
    else:
        status  = "ok"
        message = (
            f"✅  {category}: Spent ₹{spent:,.2f} of ₹{limit:,.2f} "
            f"({percent*100:.1f}%) — within budget"
        )

    return {
        "limit":   limit,
        "spent":   spent,
        "percent": percent,
        "status":  status,
        "message": message,
    }


def show_all_budget_alerts(year: int, month: int):
    """
    Checks and prints budget alerts for all categories that have
    either a budget set OR any spending in the given month.
    """
    conn = get_connection()
    # All categories with a budget
    budgeted = {r["category"] for r in conn.execute("SELECT category FROM budgets")}
    # All categories with spending this month
    month_str = f"{year}-{month:02d}"
    spent_cats = {r["category"] for r in conn.execute(
        "SELECT DISTINCT category FROM expenses WHERE expense_date LIKE ?",
        (f"{month_str}%",)
    )}
    conn.close()

    all_cats = sorted(budgeted | spent_cats)
    if not all_cats:
        cprint("\n  [dim]No budget data or spending found for this month.[/]")
        return

    print_rule(f"BUDGET ALERTS — {datetime(year, month, 1).strftime('%B %Y')}")

    alerts_found = False
    rows_data = []

    for cat in all_cats:
        result = check_budget_alert(cat, year, month)
        rows_data.append((cat, result))
        if result["status"] in ("warning", "exceeded"):
            alerts_found = True

    if RICH:
        console.print()
        tbl = Table(
            box=box.ROUNDED, border_style="dim",
            header_style="bold dim", show_lines=True
        )
        tbl.add_column("Category",  style="bold", min_width=22)
        tbl.add_column("Budget",    style="cyan",  no_wrap=True)
        tbl.add_column("Spent",     no_wrap=True)
        tbl.add_column("Remaining", no_wrap=True)
        tbl.add_column("Usage",     min_width=22)
        tbl.add_column("Status",    no_wrap=True)

        for cat, r in rows_data:
            icon = CATEGORY_ICONS.get(cat, "📋")
            remaining = r["limit"] - r["spent"] if r["limit"] > 0 else 0

            if r["status"] == "exceeded":
                status_cell = "[bold red]🚨 EXCEEDED[/]"
                bar_color   = "red"
                spent_color = "bold red"
            elif r["status"] == "warning":
                status_cell = "[bold yellow]⚠️  WARNING[/]"
                bar_color   = "yellow"
                spent_color = "bold yellow"
            elif r["status"] == "ok":
                status_cell = "[bold green]✅ OK[/]"
                bar_color   = "green"
                spent_color = "bold green"
            else:
                status_cell = "[dim]— No Budget[/]"
                bar_color   = "dim"
                spent_color = "dim"

            # Simple ASCII progress bar
            if r["limit"] > 0:
                filled = min(int(r["percent"] * 20), 20)
                bar    = f"[{bar_color}]{'█' * filled}[/][dim]{'░' * (20 - filled)}[/] {r['percent']*100:.0f}%"
                rem_str = f"₹{max(remaining,0):,.2f}"
                lim_str = f"₹{r['limit']:,.2f}"
            else:
                bar     = "[dim]Not configured[/]"
                rem_str = "[dim]—[/]"
                lim_str = "[dim]Not set[/]"

            tbl.add_row(
                f"{icon} {cat}",
                lim_str,
                f"[{spent_color}]₹{r['spent']:,.2f}[/]",
                rem_str,
                bar,
                status_cell,
            )
        console.print(tbl)

        if alerts_found:
            console.print(Panel(
                "[bold yellow]Action needed:[/] Review your high-usage categories above.\n"
                "Use [bold cyan]Option 7 → Set / Update Budget[/] to adjust limits.",
                border_style="yellow",
                title="[bold yellow]⚠️  Alerts Detected[/]",
            ))
        else:
            console.print(Panel(
                "[bold green]All categories are within budget. Keep it up![/]",
                border_style="green",
                title="[bold green]✅  All Clear[/]",
            ))
    else:
        print(f"\n  {'CATEGORY':<22} {'BUDGET':>10} {'SPENT':>10} {'REMAIN':>10}  STATUS")
        print("  " + "─" * 70)
        for cat, r in rows_data:
            lim = f"₹{r['limit']:,.2f}" if r["limit"] > 0 else "Not set"
            rem = f"₹{max(r['limit']-r['spent'],0):,.2f}" if r["limit"] > 0 else "—"
            print(f"  {cat:<22} {lim:>10} ₹{r['spent']:>9,.2f} {rem:>10}  {r['status'].upper()}")


# ─────────────────────────────────────────────────────────────────
# 4. RICH CONSOLE HELPERS
# ─────────────────────────────────────────────────────────────────

console = Console() if RICH else None


def cprint(text, style=""):
    if RICH:
        console.print(text, style=style)
    else:
        import re
        plain = re.sub(r'\[.*?\]', '', str(text))
        print(plain)


def cinput(prompt_text, default=""):
    if RICH:
        return Prompt.ask(f"[bold cyan]{prompt_text}[/]", default=default)
    else:
        val = input(f"{prompt_text}: ").strip()
        return val if val else default


def cconfirm(prompt_text):
    if RICH:
        return Confirm.ask(f"[bold yellow]{prompt_text}[/]")
    else:
        return input(f"{prompt_text} [y/N]: ").strip().lower() == "y"


def print_header():
    if RICH:
        console.print()
        console.print(Panel.fit(
            "[bold cyan]💸  AI SMART EXPENSE TRACKER[/]\n"
            "[dim]Budget Alert System  •  B.Tech AI/Data Science Project[/]",
            border_style="cyan",
            padding=(0, 4),
        ))
        console.print()
    else:
        print("\n" + "=" * 62)
        print("   AI SMART EXPENSE TRACKER — Budget Alert System")
        print("=" * 62 + "\n")


def print_rule(title=""):
    if RICH:
        console.print(Rule(f"[bold dim]{title}[/]", style="dim"))
    else:
        print(f"\n── {title} " + "─" * max(0, 50 - len(title)))


def print_success(msg): cprint(f"\n  ✅  {msg}", "bold green")
def print_error(msg):   cprint(f"\n  ❌  {msg}", "bold red")
def print_info(msg):    cprint(f"\n  ℹ️   {msg}", "dim")
def print_alert(msg):   cprint(f"\n  🚨  {msg}", "bold red")
def print_warn(msg):    cprint(f"\n  ⚠️   {msg}", "bold yellow")


# ─────────────────────────────────────────────────────────────────
# 5. FEATURE: ADD EXPENSE
# ─────────────────────────────────────────────────────────────────

def add_expense():
    print_rule("ADD NEW EXPENSE")
    cprint("\n  Fill in the details. AI will auto-detect category.\n")

    description = cinput("  Description (e.g. 'Zomato dinner order')")
    if description.lower() == "cancel":
        return

    # AI classify
    category = ai_classify(description)
    icon     = CATEGORY_ICONS.get(category, "📋")
    if RICH:
        cprint(f"\n  🤖 [bold green]AI detected category:[/] {icon} [bold]{category}[/]")
        override = cconfirm("  Keep this category? (No = choose manually)")
        if not override:
            category = _choose_category()
    else:
        print(f"\n  AI detected category: {category}")
        yn = input("  Override category? [y/N]: ").strip().lower()
        if yn == "y":
            category = _choose_category()

    # Amount
    while True:
        try:
            amount_str = cinput("  Amount (₹)")
            amount = float(amount_str.replace(",", "").replace("₹", "").strip())
            if amount <= 0:
                raise ValueError
            break
        except ValueError:
            print_error("Enter a valid positive number.")

    # Payment mode
    cprint("\n  Payment modes: " + "  ".join(
        [f"[bold]{i+1}[/]. {m}" for i, m in enumerate(PAYMENT_MODES)]
    ))
    while True:
        pm_choice = cinput("  Choose payment mode", "1")
        try:
            payment_mode = PAYMENT_MODES[int(pm_choice) - 1]
            break
        except (ValueError, IndexError):
            print_error("Enter a number between 1 and 6.")

    # Date
    today = date.today().isoformat()
    date_input = cinput(f"  Expense date (YYYY-MM-DD) [default: {today}]", today)
    try:
        datetime.strptime(date_input, "%Y-%m-%d")
        expense_date = date_input
    except ValueError:
        print_warn("Invalid date format. Using today.")
        expense_date = today

    note = cinput("  Optional note (or press Enter to skip)", "")

    # Save
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_connection()
    conn.execute(
        """INSERT INTO expenses
           (description, amount, category, payment_mode, note, expense_date, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (description, amount, category, payment_mode, note, expense_date, now)
    )
    conn.commit()
    conn.close()

    print_success(f"Expense ₹{amount:,.2f} added under '{category}' via {payment_mode}.")

    # ── Trigger budget alert check immediately after adding ──
    year, month, _ = [int(p) for p in expense_date.split("-")]
    alert = check_budget_alert(category, year, month)
    if alert["status"] == "exceeded":
        print_alert(alert["message"])
    elif alert["status"] == "warning":
        print_warn(alert["message"])
    elif alert["status"] == "ok":
        print_info(alert["message"])

    input("\n  Press Enter to return to main menu...")


def _choose_category() -> str:
    cats = list(CATEGORY_KEYWORDS.keys()) + ["Other"]
    cprint("\n  Available categories:")
    for i, c in enumerate(cats):
        cprint(f"    [bold]{i+1}[/]. {CATEGORY_ICONS.get(c,'📋')} {c}")
    while True:
        try:
            choice = int(cinput("  Enter number", "1"))
            return cats[choice - 1]
        except (ValueError, IndexError):
            print_error("Invalid choice.")


# ─────────────────────────────────────────────────────────────────
# 6. FEATURE: VIEW ALL EXPENSES
# ─────────────────────────────────────────────────────────────────

def view_expenses(filter_cat="All", filter_month="", filter_mode="All"):
    print_rule("EXPENSE RECORDS")

    conn   = get_connection()
    query  = "SELECT * FROM expenses WHERE 1=1"
    params = []

    if filter_cat != "All":
        query += " AND category = ?";      params.append(filter_cat)
    if filter_month:
        query += " AND expense_date LIKE ?"; params.append(f"{filter_month}%")
    if filter_mode != "All":
        query += " AND payment_mode = ?";  params.append(filter_mode)

    query += " ORDER BY expense_date DESC, id DESC"
    rows   = conn.execute(query, params).fetchall()

    # Summary stats from full table
    stats  = conn.execute(
        "SELECT COUNT(*) as cnt, COALESCE(SUM(amount),0) as total FROM expenses"
    ).fetchone()
    conn.close()

    if RICH:
        console.print()
        cprint(
            f"  [dim]Total records:[/] [bold cyan]{stats['cnt']}[/]   "
            f"[dim]All-time total:[/] [bold cyan]₹{stats['total']:,.2f}[/]"
        )
        if filter_cat != "All" or filter_month or filter_mode != "All":
            row_total = sum(r["amount"] for r in rows)
            cprint(f"  [dim]Filtered results:[/] [bold]{len(rows)}[/] records  "
                   f"[dim]Total:[/] [bold]₹{row_total:,.2f}[/]\n")

        if not rows:
            cprint("\n  [dim]No expenses found.[/]")
            input("\n  Press Enter to return...")
            return

        tbl = Table(
            box=box.ROUNDED, border_style="dim",
            header_style="bold dim", show_lines=True
        )
        tbl.add_column("#",           style="dim",   width=5)
        tbl.add_column("Date",        style="dim",   no_wrap=True)
        tbl.add_column("Description", max_width=28)
        tbl.add_column("Amount",      style="bold cyan", no_wrap=True)
        tbl.add_column("Category",    no_wrap=True)
        tbl.add_column("Mode",        style="dim",   no_wrap=True)
        tbl.add_column("Note",        max_width=20,  style="dim")

        for r in rows:
            icon = CATEGORY_ICONS.get(r["category"], "📋")
            tbl.add_row(
                str(r["id"]),
                r["expense_date"],
                r["description"][:28],
                f"₹{r['amount']:,.2f}",
                f"{icon} {r['category']}",
                r["payment_mode"],
                r["note"][:20] if r["note"] else "—",
            )
        console.print(tbl)

    else:
        print(f"\n  Total records: {stats['cnt']}  |  All-time: ₹{stats['total']:,.2f}\n")
        if not rows:
            print("  No expenses found.")
            input("\n  Press Enter to return...")
            return
        fmt = "  {:<4} {:<12} {:<28} {:>10}  {:<20}  {}"
        print(fmt.format("ID", "DATE", "DESCRIPTION", "AMOUNT", "CATEGORY", "MODE"))
        print("  " + "─" * 90)
        for r in rows:
            print(fmt.format(
                r["id"], r["expense_date"], r["description"][:28],
                f"₹{r['amount']:,.2f}", r["category"][:20], r["payment_mode"]
            ))

    input("\n  Press Enter to return to main menu...")


# ─────────────────────────────────────────────────────────────────
# 7. FEATURE: FILTER EXPENSES
# ─────────────────────────────────────────────────────────────────

def filter_expenses_menu():
    print_rule("FILTER EXPENSES")

    cats = list(CATEGORY_KEYWORDS.keys()) + ["Other"]
    cprint("\n  [dim]Category filter:[/]")
    cprint("    [bold]0[/]. All categories")
    for i, c in enumerate(cats):
        cprint(f"    [bold]{i+1}[/]. {CATEGORY_ICONS.get(c,'📋')} {c}")
    cat_in = cinput("\n  Category number", "0")
    try:
        filter_cat = cats[int(cat_in) - 1] if cat_in != "0" else "All"
    except (ValueError, IndexError):
        filter_cat = "All"

    filter_month = cinput(
        "\n  Month filter (YYYY-MM, e.g. 2025-06) or Enter to skip", ""
    ).strip()

    cprint("\n  Payment mode filter: " + "  ".join(
        [f"[bold]{i+1}[/]. {m}" for i, m in enumerate(PAYMENT_MODES)]
    ) + "  [bold]0[/]. All")
    mode_in = cinput("  Mode number", "0")
    try:
        filter_mode = PAYMENT_MODES[int(mode_in) - 1] if mode_in != "0" else "All"
    except (ValueError, IndexError):
        filter_mode = "All"

    view_expenses(filter_cat, filter_month, filter_mode)


# ─────────────────────────────────────────────────────────────────
# 8. FEATURE: SET / UPDATE BUDGET
# ─────────────────────────────────────────────────────────────────

def set_budget():
    print_rule("SET MONTHLY BUDGET")

    cats = list(CATEGORY_KEYWORDS.keys()) + ["Other"]
    cprint("\n  Choose a category to set or update its monthly budget:\n")
    for i, c in enumerate(cats):
        current = get_budget_limit(c)
        lim_str = f"[dim](current: ₹{current:,.2f})[/]" if current > 0 else "[dim](not set)[/]"
        cprint(f"    [bold]{i+1}[/]. {CATEGORY_ICONS.get(c,'📋')} {c}  {lim_str}")

    cat_in = cinput("\n  Category number")
    try:
        category = cats[int(cat_in) - 1]
    except (ValueError, IndexError):
        print_error("Invalid choice.")
        input("\n  Press Enter to return...")
        return

    while True:
        try:
            limit_str = cinput(f"  Monthly budget for {category} (₹)")
            limit = float(limit_str.replace(",", "").replace("₹", "").strip())
            if limit <= 0:
                raise ValueError
            break
        except ValueError:
            print_error("Enter a valid positive amount.")

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_connection()
    conn.execute(
        """INSERT INTO budgets (category, monthly_limit, updated_at)
           VALUES (?, ?, ?)
           ON CONFLICT(category) DO UPDATE
           SET monthly_limit = excluded.monthly_limit,
               updated_at    = excluded.updated_at""",
        (category, limit, now)
    )
    conn.commit()
    conn.close()

    print_success(f"Budget for '{category}' set to ₹{limit:,.2f} / month.")

    # Immediately show current month status
    today = date.today()
    alert = check_budget_alert(category, today.year, today.month)
    if alert["status"] == "exceeded":
        print_alert(alert["message"])
    elif alert["status"] == "warning":
        print_warn(alert["message"])
    else:
        print_info(alert["message"])

    input("\n  Press Enter to return to main menu...")


# ─────────────────────────────────────────────────────────────────
# 9. FEATURE: BUDGET ALERT DASHBOARD
# ─────────────────────────────────────────────────────────────────

def budget_alert_dashboard():
    print_rule("BUDGET ALERT DASHBOARD")

    today = date.today()
    default_month = today.strftime("%Y-%m")
    month_in = cinput(
        f"\n  Check budget for month (YYYY-MM) [default: {default_month}]",
        default_month
    ).strip()

    try:
        year, month = [int(p) for p in month_in.split("-")]
        datetime(year, month, 1)   # validate
    except (ValueError, AttributeError):
        print_error("Invalid month. Using current month.")
        year, month = today.year, today.month

    show_all_budget_alerts(year, month)
    input("\n  Press Enter to return to main menu...")


# ─────────────────────────────────────────────────────────────────
# 10. FEATURE: MONTHLY SUMMARY
# ─────────────────────────────────────────────────────────────────

def monthly_summary():
    print_rule("MONTHLY SPENDING SUMMARY")

    today = date.today()
    default_month = today.strftime("%Y-%m")
    month_in = cinput(
        f"\n  Summary for month (YYYY-MM) [default: {default_month}]",
        default_month
    ).strip()

    try:
        year, month = [int(p) for p in month_in.split("-")]
        datetime(year, month, 1)
    except (ValueError, AttributeError):
        print_error("Invalid month. Using current month.")
        year, month = today.year, today.month

    month_str  = f"{year}-{month:02d}"
    month_label = datetime(year, month, 1).strftime("%B %Y")

    conn = get_connection()
    rows = conn.execute(
        """SELECT category, SUM(amount) as total, COUNT(*) as count
           FROM expenses
           WHERE expense_date LIKE ?
           GROUP BY category
           ORDER BY total DESC""",
        (f"{month_str}%",)
    ).fetchall()
    grand_total = conn.execute(
        "SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE expense_date LIKE ?",
        (f"{month_str}%",)
    ).fetchone()["t"]
    conn.close()

    if not rows:
        print_info(f"No expenses recorded for {month_label}.")
        input("\n  Press Enter to return...")
        return

    print_rule(f"SUMMARY — {month_label}")

    if RICH:
        console.print()
        tbl = Table(
            box=box.ROUNDED, border_style="dim",
            header_style="bold dim", show_lines=False
        )
        tbl.add_column("Category",    style="bold", min_width=22)
        tbl.add_column("Transactions", style="dim",  no_wrap=True)
        tbl.add_column("Spent",        style="bold cyan", no_wrap=True)
        tbl.add_column("% of Total",   no_wrap=True)
        tbl.add_column("Spending Bar", min_width=25)
        tbl.add_column("Budget Status", no_wrap=True)

        for r in rows:
            pct   = (r["total"] / grand_total * 100) if grand_total > 0 else 0
            icon  = CATEGORY_ICONS.get(r["category"], "📋")
            bar   = "█" * int(pct / 4)  + "░" * (25 - int(pct / 4))

            alert  = check_budget_alert(r["category"], year, month)
            if alert["status"] == "exceeded":
                badge = "[bold red]🚨 Over[/]"
            elif alert["status"] == "warning":
                badge = "[bold yellow]⚠️  Near[/]"
            elif alert["status"] == "ok":
                badge = "[bold green]✅ OK[/]"
            else:
                badge = "[dim]No limit[/]"

            tbl.add_row(
                f"{icon} {r['category']}",
                str(r["count"]),
                f"₹{r['total']:,.2f}",
                f"{pct:.1f}%",
                f"[cyan]{bar}[/]",
                badge,
            )

        console.print(tbl)
        console.print(
            f"\n  [dim]Grand Total for {month_label}:[/] "
            f"[bold cyan]₹{grand_total:,.2f}[/]"
        )

    else:
        print(f"\n  {'CATEGORY':<22} {'TXN':>5} {'SPENT':>12}  {'%':>6}  STATUS")
        print("  " + "─" * 65)
        for r in rows:
            pct   = (r["total"] / grand_total * 100) if grand_total > 0 else 0
            alert = check_budget_alert(r["category"], year, month)
            print(f"  {r['category']:<22} {r['count']:>5} ₹{r['total']:>11,.2f}  {pct:>5.1f}%  {alert['status'].upper()}")
        print(f"\n  Grand Total: ₹{grand_total:,.2f}")

    input("\n  Press Enter to return to main menu...")


# ─────────────────────────────────────────────────────────────────
# 11. FEATURE: DELETE EXPENSE
# ─────────────────────────────────────────────────────────────────

def delete_expense():
    print_rule("DELETE EXPENSE")

    try:
        exp_id = int(cinput("\n  Enter expense ID to delete"))
    except ValueError:
        print_error("Invalid ID.")
        input("\n  Press Enter to return...")
        return

    conn   = get_connection()
    row    = conn.execute("SELECT * FROM expenses WHERE id = ?", (exp_id,)).fetchone()

    if not row:
        print_error(f"No expense found with ID {exp_id}.")
        conn.close()
        input("\n  Press Enter to return...")
        return

    cprint(
        f"\n  [bold red]About to delete:[/]  ID {row['id']}  |  "
        f"{row['expense_date']}  |  {row['description']}  |  ₹{row['amount']:,.2f}"
    )

    if cconfirm("  Confirm delete?"):
        conn.execute("DELETE FROM expenses WHERE id = ?", (exp_id,))
        conn.commit()
        print_success(f"Expense #{exp_id} deleted.")
    else:
        print_info("Delete cancelled.")

    conn.close()
    input("\n  Press Enter to return to main menu...")


# ─────────────────────────────────────────────────────────────────
# 12. MAIN MENU
# ─────────────────────────────────────────────────────────────────

MENU_OPTIONS = [
    ("1", "➕  Add new expense"),
    ("2", "📋  View all expenses"),
    ("3", "🔍  Filter expenses"),
    ("4", "🚨  Budget Alert Dashboard"),
    ("5", "📊  Monthly spending summary"),
    ("6", "💰  Set / Update monthly budget"),
    ("7", "🗑️   Delete an expense"),
    ("0", "🚪  Exit"),
]


def print_menu():
    if RICH:
        console.print()
        tbl = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        tbl.add_column(style="bold cyan", width=5)
        tbl.add_column()
        for key, label in MENU_OPTIONS:
            tbl.add_row(f"[{key}]", label)
        console.print(tbl)
        console.print()
    else:
        print()
        for key, label in MENU_OPTIONS:
            print(f"  [{key}] {label}")
        print()


def _startup_alerts():
    """Show any active budget alerts for the current month at startup."""
    today   = date.today()
    conn    = get_connection()
    month_str = today.strftime("%Y-%m")
    spent_cats = [r["category"] for r in conn.execute(
        "SELECT DISTINCT category FROM expenses WHERE expense_date LIKE ?",
        (f"{month_str}%",)
    )]
    budgeted = [r["category"] for r in conn.execute("SELECT category FROM budgets")]
    conn.close()

    alerts = []
    for cat in set(spent_cats + budgeted):
        result = check_budget_alert(cat, today.year, today.month)
        if result["status"] in ("warning", "exceeded"):
            alerts.append(result)

    if alerts:
        if RICH:
            lines = "\n".join(r["message"] for r in alerts)
            console.print(Panel(
                lines,
                title=f"[bold red]🚨  ACTIVE BUDGET ALERTS — {today.strftime('%B %Y')}[/]",
                border_style="red",
            ))
        else:
            print("\n  *** ACTIVE BUDGET ALERTS ***")
            for r in alerts:
                print(f"  {r['message']}")
            print()


def main():
    init_db()
    os.system("cls" if os.name == "nt" else "clear")
    print_header()

    if not RICH:
        print("  TIP: Install 'rich' for a better experience:  pip install rich\n")

    # Show active alerts at startup
    _startup_alerts()

    while True:
        print_menu()
        choice = cinput("  Select option", "")

        if   choice == "1": add_expense()
        elif choice == "2": view_expenses()
        elif choice == "3": filter_expenses_menu()
        elif choice == "4": budget_alert_dashboard()
        elif choice == "5": monthly_summary()
        elif choice == "6": set_budget()
        elif choice == "7": delete_expense()
        elif choice == "0":
            cprint("\n  [bold cyan]Goodbye! 👋[/]\n")
            sys.exit(0)
        else:
            print_error("Invalid option. Choose a number from the menu.")


if __name__ == "__main__":
    main()
